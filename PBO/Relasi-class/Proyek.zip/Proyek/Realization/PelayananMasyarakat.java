package Realization;

public interface PelayananMasyarakat {
    void prosesPermohonan(String namaPemohon);
    void cetakDokumen(String namaPemohon);
}
